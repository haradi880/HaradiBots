const spotlight = document.querySelector('.spotlight');
const menuToggle = document.querySelector('.menu-toggle');
const sideNav = document.querySelector('.side-nav');

// Update spotlight position based on mouse movement
document.addEventListener('mousemove', (e) => {
    const { clientX, clientY } = e;

    // Get hero section dimensions
    const hero = document.querySelector('.hero');
    const { left, top } = hero.getBoundingClientRect();

    // Check if mouse is within the hero section
    if (clientX >= left && clientX <= left + hero.clientWidth &&
        clientY >= top && clientY <= top + hero.clientHeight) {
        
        spotlight.style.setProperty('--x', `${clientX}px`);
        spotlight.style.setProperty('--y', `${clientY}px`);
        spotlight.style.background = `radial-gradient(circle at ${clientX}px ${clientY}px, rgba(255, 255, 255, 0) 60px, rgba(0, 0, 0, 0.8) 100px)`;
    }
});

// Toggle side navigation and rotate menu icon
menuToggle.addEventListener('click', () => {
    sideNav.classList.toggle('show'); // Toggle the side navigation
    menuToggle.classList.toggle('rotated'); // Rotate the icon
});
