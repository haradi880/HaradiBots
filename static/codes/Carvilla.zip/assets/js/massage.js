document.getElementById('subscribeForm').addEventListener('submit', function (e) {
    e.preventDefault();
    var email = document.getElementById('email').value;

    // Send the email to Zapier or Integromat via API
    fetch('YOUR_ZAPIER_WEBHOOK_URL', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            email: email
        })
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('response').innerHTML = 'Thank you for subscribing!';
    })
    .catch(error => {
        console.error('Error:', error);
        document.getElementById('response').innerHTML = 'An error occurred!';
    });
});
